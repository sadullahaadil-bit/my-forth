# Assignment 4B - TypeScript Task Manager

## Overview
A fully-typed Task Management CLI built in NodeJS using **Strict TypeScript**.

## Features Built
- **Strict Typing Rules**: `tsconfig.json` ensures strictly enforced types and zero implicit `any`.
- **Enums & Interfaces**: Uses deeply integrated TypeScript structures to govern Task shape and properties.
- **Node Data Persistence**: Saves and hydrates data intelligently from the file system.
- **Compiled**: Uses `tsc` via the npm runtime scripts to cleanly transpile TS to standard JS before booting the app.

## Execution
Run:
```bash
setup.bat
```
*(Author: sadullahaadil-bit)*
