# Assignment 4C - Angular Finance Tracker

## Overview
A reactive Angular application constructed exactly to the specifications of the Finance Tracker prompt.

## Features
- **Reactive Forms**: `transactions.component.ts` utilizes `FormGroup` and `FormBuilder` with deep validation.
- **RxJS & Services**: API calls are routed entirely through `finance.service.ts` using Observables, `catchError`, and pipes.
- **HTTP Interceptor**: Functional central error interception handles failing API requests dynamically alerting the user.
- **Component Architecture**: Built using the modern Angular Standalone Component routing mechanisms.

*(Author: sadullahaadil-bit)*
