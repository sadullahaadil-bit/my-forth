import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FinanceService, Transaction } from '../../services/finance.service';

@Component({
  selector: 'app-transactions',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <h2>Transactions</h2>
    <form [formGroup]="txnForm" (ngSubmit)="onSubmit()">
      <div>
        <label>Description:</label>
        <input formControlName="description" />
        <div *ngIf="txnForm.get('description')?.invalid && txnForm.get('description')?.touched" class="error">
          Description is required.
        </div>
      </div>
      
      <div>
        <label>Amount:</label>
        <input type="number" formControlName="amount" />
        <div *ngIf="txnForm.get('amount')?.invalid && txnForm.get('amount')?.touched" class="error">
          A valid numeric amount is required.
        </div>
      </div>

      <div>
        <label>Category:</label>
        <input formControlName="category" />
      </div>

      <button type="submit" [disabled]="txnForm.invalid">Add Transaction</button>
    </form>

    <ul>
      <li *ngFor="let t of transactions">
        {{ t.description }} - \${{ t.amount }} ({{ t.category }})
      </li>
    </ul>
  `,
  styles: [`.error { color: red; font-size: 0.8rem; }`]
})
export class TransactionsComponent implements OnInit {
  txnForm: FormGroup;
  transactions: Transaction[] = [];

  constructor(private fb: FormBuilder, private financeService: FinanceService) {
    this.txnForm = this.fb.group({
      description: ['', Validators.required],
      amount: [0, [Validators.required, Validators.pattern(/^-?\d+$/)]],
      category: ['']
    });
  }

  ngOnInit() {
    this.financeService.getTransactions().subscribe(data => this.transactions = data);
  }

  onSubmit() {
    if (this.txnForm.valid) {
      this.financeService.addTransaction(this.txnForm.value).subscribe(newTxn => {
        this.transactions.push(newTxn);
        this.txnForm.reset();
      });
    }
  }
}
