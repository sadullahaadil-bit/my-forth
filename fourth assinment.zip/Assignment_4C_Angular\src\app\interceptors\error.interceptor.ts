import { HttpInterceptorFn } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  return next(req).pipe(
    catchError((error) => {
      console.error('Interceptor caught an API error:', error);
      alert('A network error occurred. Please try again later.'); // User-friendly notification
      return throwError(() => error);
    })
  );
};
