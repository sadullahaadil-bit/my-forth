import * as fs from 'fs';
import * as path from 'path';
import { Task, Priority, Status } from './types';

export class TaskManager {
    private dataFile: string;
    private tasks: Task[];

    constructor() {
        this.dataFile = path.resolve(__dirname, '../../tasks.json');
        this.tasks = [];
        this.loadTasks();
    }

    private loadTasks(): void {
        if (!fs.existsSync(this.dataFile)) return;
        try {
            const rawData = fs.readFileSync(this.dataFile, 'utf-8');
            this.tasks = JSON.parse(rawData);
            // Re-hydrate dates
            for (const t of this.tasks) {
                if (t.dueDate) t.dueDate = new Date(t.dueDate);
            }
        } catch (error) {
            console.error("Could not load tasks, starting fresh.");
        }
    }

    private saveTasks(): void {
        fs.writeFileSync(this.dataFile, JSON.stringify(this.tasks, null, 2), 'utf-8');
    }

    private getNextId(): number {
        return this.tasks.length > 0 ? Math.max(...this.tasks.map(t => t.id)) + 1 : 1;
    }

    public addTask(title: string, priority: Priority, dueDate?: string): void {
        const newTask: Task = {
            id: this.getNextId(),
            title,
            priority,
            status: Status.PENDING,
            dueDate: dueDate ? new Date(dueDate) : undefined
        };
        this.tasks.push(newTask);
        this.saveTasks();
        console.log(`\n[SUCCESS] Task added with ID: ${newTask.id}`);
    }

    public listTasks(): void {
        // Sort by priority logic (High > Medium > Low)
        const priorityOrder: Record<Priority, number> = {
            [Priority.HIGH]: 1,
            [Priority.MEDIUM]: 2,
            [Priority.LOW]: 3,
        };

        const sorted = [...this.tasks].sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
        
        console.log("\n--- Task List ---");
        if (sorted.length === 0) {
            console.log("No tasks found.");
            return;
        }

        sorted.forEach(t => {
            const dateStr = t.dueDate instanceof Date && !isNaN(t.dueDate.getTime()) ? t.dueDate.toISOString().split('T')[0] : "None";
            console.log(`[${t.id}] ${t.title} | Priority: ${t.priority.toUpperCase()} | Status: ${t.status.toUpperCase()} | Due: ${dateStr}`);
        });
    }

    public markComplete(id: number): void {
        const t = this.tasks.find(x => x.id === id);
        if (t) {
            t.status = Status.COMPLETED;
            this.saveTasks();
            console.log(`\n[SUCCESS] Task ${id} marked complete.`);
        } else {
            console.log(`\n[ERROR] Task ID ${id} not found.`);
        }
    }

    public deleteTask(id: number): void {
        const idx = this.tasks.findIndex(x => x.id === id);
        if (idx !== -1) {
            this.tasks.splice(idx, 1);
            this.saveTasks();
            console.log(`\n[SUCCESS] Task ${id} deleted.`);
        } else {
            console.log(`\n[ERROR] Task ID ${id} not found.`);
        }
    }
}
