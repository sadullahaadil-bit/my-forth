// Assignment 4A - Weather Dashboard
// Author: sadullahaadil-bit

const input = document.getElementById('cityInput');
const searchBtn = document.getElementById('searchBtn');
const loading = document.getElementById('loading');
const errorBox = document.getElementById('errorBox');
const weatherResult = document.getElementById('weatherResult');

// DOM Elements for updating
const cityNameEl = document.getElementById('cityName');
const weatherIconEl = document.getElementById('weatherIcon');
const tempEl = document.getElementById('temperature');
const condEl = document.getElementById('condition');
const windEl = document.getElementById('windSpeed');

// Add Event Listeners
searchBtn.addEventListener('click', handleSearch);
input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleSearch();
});

async function handleSearch() {
    const city = input.value.trim();
    if (!city) return;

    // Reset UI
    errorBox.classList.add('hidden');
    weatherResult.classList.add('hidden');
    loading.classList.remove('hidden');

    try {
        const coords = await getCoordinates(city);
        const weather = await getWeather(coords.latitude, coords.longitude);
        updateUI(coords.name, weather);
    } catch (error) {
        showError(error.message);
    } finally {
        loading.classList.add('hidden');
    }
}

async function getCoordinates(city) {
    const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`);
    if (!res.ok) throw new Error("Failed to fetch coordinates.");
    
    const data = await res.json();
    if (!data.results || data.results.length === 0) {
        throw new Error("City not found. Please try another name.");
    }
    
    return data.results[0]; // returns { name, latitude, longitude, ... }
}

async function getWeather(lat, lon) {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Failed to fetch weather data.");
    
    const data = await res.json();
    return data.current_weather;
}

function updateUI(name, weatherObj) {
    cityNameEl.textContent = name;
    tempEl.textContent = `${weatherObj.temperature}°C`;
    windEl.textContent = `Wind: ${weatherObj.windspeed} km/h`;
    
    // WMO Weather interpretation codes mapping
    const code = weatherObj.weathercode;
    let icon = '❓';
    let condition = 'Unknown';

    if (code === 0) { icon = '☀️'; condition = 'Clear sky'; }
    else if ([1,2,3].includes(code)) { icon = '⛅'; condition = 'Partly cloudy'; }
    else if ([45,48].includes(code)) { icon = '🌫️'; condition = 'Fog'; }
    else if ([51,53,55,56,57].includes(code)) { icon = '🌧️'; condition = 'Drizzle'; }
    else if ([61,63,65,66,67].includes(code)) { icon = '🌧️'; condition = 'Rain'; }
    else if ([71,73,75,77].includes(code)) { icon = '❄️'; condition = 'Snow'; }
    else if ([80,81,82].includes(code)) { icon = '🌦️'; condition = 'Rain showers'; }
    else if ([95,96,99].includes(code)) { icon = '🌩️'; condition = 'Thunderstorm'; }

    weatherIconEl.textContent = icon;
    condEl.textContent = condition;

    weatherResult.classList.remove('hidden');
}

function showError(msg) {
    errorBox.textContent = msg;
    errorBox.classList.remove('hidden');
}
