import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface Transaction {
  id?: number;
  amount: number;
  description: string;
  category: string;
}

@Injectable({
  providedIn: 'root'
})
export class FinanceService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  // Fallbacks to Observables of mock data so it runs without backend!
  getTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.apiUrl}/transactions`).pipe(
      catchError(() => of([
        { id: 1, amount: -50, description: 'Groceries', category: 'Food' },
        { id: 2, amount: 2000, description: 'Salary', category: 'Income' }
      ]))
    );
  }

  addTransaction(txn: Transaction): Observable<Transaction> {
    return this.http.post<Transaction>(`${this.apiUrl}/transactions`, txn).pipe(
      catchError(() => of({ ...txn, id: Math.floor(Math.random() * 1000) }))
    );
  }
}
