import * as readline from 'readline';
import { TaskManager } from './TaskManager';
import { Priority } from './types';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const manager = new TaskManager();

function displayMenu() {
    console.log("\n=============================");
    console.log(" TS CLI Task Manager (Assn 4B)");
    console.log(" By: sadullahaadil-bit");
    console.log("=============================");
    console.log("1. Add Task");
    console.log("2. List Tasks");
    console.log("3. Mark Task Complete");
    console.log("4. Delete Task");
    console.log("5. Exit\n");
    rl.question("Choose an option: ", handleInput);
}

function handleInput(choice: string) {
    switch (choice.trim()) {
        case '1':
            rl.question("Title: ", (title) => {
                rl.question("Priority (low/medium/high): ", (priInput) => {
                    let p = Priority.LOW;
                    if (priInput === 'high') p = Priority.HIGH;
                    if (priInput === 'medium') p = Priority.MEDIUM;
                    
                    rl.question("Due Date (optional YYYY-MM-DD): ", (due) => {
                        manager.addTask(title, p, due || undefined);
                        displayMenu();
                    });
                });
            });
            break;
        case '2':
            manager.listTasks();
            displayMenu();
            break;
        case '3':
            rl.question("Enter Task ID: ", (idStr) => {
                const id = parseInt(idStr, 10);
                if (!isNaN(id)) manager.markComplete(id);
                else console.log("Invalid ID.");
                displayMenu();
            });
            break;
        case '4':
            rl.question("Enter Task ID: ", (idStr) => {
                const id = parseInt(idStr, 10);
                if (!isNaN(id)) manager.deleteTask(id);
                else console.log("Invalid ID.");
                displayMenu();
            });
            break;
        case '5':
            console.log("Goodbye!");
            rl.close();
            process.exit(0);
        default:
            console.log("Invalid option.");
            displayMenu();
            break;
    }
}

// Start app
displayMenu();
