# Assignment 4A - Weather Dashboard

## Overview
A minimalist Weather Dashboard built completely with **Vanilla JavaScript** (ES6+) without any external libraries or frameworks (no jQuery, no React).

## Features Designed
- **Open-Meteo Integration**: Connects to the free Open-Meteo API using standard standard `fetch()`.
- **Async/Await**: Properly structured logic to await async HTTP requests.
- **Error Handling**: gracefully catches typos or missing locations with `try/catch`. 
- **DOM Manipulation**: Displays accurate icons based on WMO codes without reloading the page.
- **Loading State**: Displays a loading spinner while awaiting the cloud response.

## Instructions
Just open `index.html` locally in any modern browser! You can safely deploy this to Vercel or Netlify by just dropping the folder directly onto the dashboard.
