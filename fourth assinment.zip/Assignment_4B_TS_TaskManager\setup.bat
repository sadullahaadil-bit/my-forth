@echo off
echo ==============================================
echo Installing Typescript and Compiling
echo ==============================================

npm install
npm run build

echo.
echo ==============================================
echo Starting Application
echo ==============================================

npm start
pause
