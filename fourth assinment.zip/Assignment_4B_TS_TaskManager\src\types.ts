export enum Priority {
    LOW = "low",
    MEDIUM = "medium",
    HIGH = "high"
}

export enum Status {
    PENDING = "pending",
    COMPLETED = "completed"
}

export interface Task {
    id: number;
    title: string;
    priority: Priority;
    status: Status;
    dueDate?: Date;
}
